const freshState = () => ({
    recents: null,
    active: null
});

const getters = {
  //
};

const mutations = {
    //
};

const actions = {
    //
};

export default {
  namespaced: true,
  state: freshState(),
  getters,
  mutations,
  actions
};
