<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Juicy(fx) PHP Now Builders</title>
</head>
<body>
    <h1>Juicy(fx) PHP Now Builders</h1>

    <ul>
        <li><a href="/phpinfo.php">PHPINFO</a></li>
        <li><a href="/dump.php">DUMP</a></li>
        <li><a href="/tracy.php">Tracy Debugger</a></li>
        <li><a href="/checker.php">Nette Checker</a></li>
    </ul>

    <hr>

    Copyright &copy; <?=date('Y')?>
</body>
</html>
