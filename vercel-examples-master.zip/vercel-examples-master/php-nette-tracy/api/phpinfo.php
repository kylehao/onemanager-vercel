<?php
phpinfo();
var_dump(opcache_get_status());