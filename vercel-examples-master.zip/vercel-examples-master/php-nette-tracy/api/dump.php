<?php

var_dump(get_loaded_extensions(false));
var_dump(get_loaded_extensions(true));
var_dump(getallheaders());
var_dump($_SERVER);
var_dump($_ENV);
